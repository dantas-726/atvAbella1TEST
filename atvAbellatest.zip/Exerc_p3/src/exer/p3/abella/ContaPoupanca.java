package exer.p3.abella;

public class ContaPoupanca extends ContaCorrente {

}
